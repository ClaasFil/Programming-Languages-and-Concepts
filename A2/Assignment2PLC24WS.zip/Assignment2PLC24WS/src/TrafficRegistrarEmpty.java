public class TrafficRegistrarEmpty implements TrafficRegistrar {

	public void registerLeft(Vehicle v) {
	}
	
	public void registerRight(Vehicle v) {
	}
	
	public void deregisterLeft(Vehicle v) {
	}
	
	public void deregisterRight(Vehicle v) {
	}
    
}
