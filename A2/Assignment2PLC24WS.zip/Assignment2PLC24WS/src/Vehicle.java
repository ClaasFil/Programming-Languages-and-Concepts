public interface Vehicle {	
	int getId();
}
