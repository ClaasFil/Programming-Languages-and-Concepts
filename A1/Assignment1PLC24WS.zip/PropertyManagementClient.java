public class PropertyManagementClient {
    public static void main(String[] args) {
    }
}