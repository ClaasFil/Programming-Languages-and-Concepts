public class RentedApartment {
}