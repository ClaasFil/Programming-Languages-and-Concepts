public class OwnedApartment {
}