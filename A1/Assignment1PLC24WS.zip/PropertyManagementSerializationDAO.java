public class PropertyManagementSerializationDAO {
}